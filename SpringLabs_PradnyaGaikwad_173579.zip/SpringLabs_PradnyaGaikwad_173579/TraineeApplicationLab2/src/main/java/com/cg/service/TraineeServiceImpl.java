package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TraineeRepo;
@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
	
	@Autowired
	TraineeRepo repo;

	@Override
	public Trainee addTrainee(Trainee trainee) {
		
		return repo.save(trainee);
	}

	@Override
	public Trainee modifyTrainee(int traineeId, Trainee t) {
		
		return null;
	}

	@Override
	public Trainee getTrainee(int id) {
		return repo.findOne(id);
	}

	@Override
	public Iterable<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteTrainee(Trainee trainee) {
	
			
			repo.delete(trainee);
		

	}

}
