package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	ArrayList<String> cityList;
	ArrayList<String> domainList;
	Trainee trainee;

	@Autowired
	TraineeService serObj;

	//by default navigate route to login  page
	@RequestMapping(value = "/")
	public String prepareLogin(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}

	//Login validation on dynamic values
	@RequestMapping(value = "/checkLogin")
	public String validateLogin(@ModelAttribute("login")

	@Valid Login login, BindingResult result) // Binding res- stores errors
	{
		if (result.hasErrors()) {
			System.out.println("Error");
			return "login";
		} else {
			return "traineeMenu";
		}

	}

	//display trainee menu
	@RequestMapping(value = "/displayMenu")
	public String TraineeMenu(Model model) {
		model.addAttribute("traineeMenu", new Trainee());

		return "traineeReg";
	}

	//choice-1 Add trainee
	//validate input on add
	@RequestMapping("validTr")
	public String validateAdd(@ModelAttribute("newTrainee") @Valid Trainee trObj, BindingResult result, Model model) {

		if (result.hasErrors()) {
			model.addAttribute("errMsg", "Invalid details");
			model.addAttribute("cityList", cityList);
			model.addAttribute("domain", domainList);
			return "addTrainee";
		} else {
			serObj.addTrainee(trObj);
			model.addAttribute("operation", "Trainee Added Successfully");
			return "traineeMenu";
		}

	}

	//add
	@RequestMapping("/addTrainee")
	public String addTrainee(Model model) {

		model.addAttribute("newTrainee", new Trainee());
		cityList = new ArrayList<String>();

		cityList.add("Chennai");
		cityList.add("Bangalore");
		cityList.add("Pune");
		cityList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("SAP");
		model.addAttribute("cityList", cityList);
		model.addAttribute("domainList", domainList);
		return "addTrainee";
	}

	//choice 2: Delete
	//get id for delete
	@RequestMapping("getidfordelete")
	public String getIdForDelete(int id, Model model) {
		trainee = serObj.getTrainee(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		return "deleteTrainee";

	}

	//check validation for Id
	@RequestMapping("checkdelete")
	public String validateDelete(Model model) {
		System.out.println(trainee);
		if (trainee != null) {
			serObj.deleteTrainee(trainee);
			trainee = null;
			model.addAttribute("operation", "Trainee deleted");
			return "traineeMenu";
		} else {
			model.addAttribute("error", "Invalid Trainee Id");
			return "deleteTrainee";
		}

	}

	//after validating,delete
	@RequestMapping("/deleteTrainee")
	public String delete(Model model) {
		model.addAttribute("trainee", null);
		return "deleteTrainee";
	}

	//choice 3: Modify record
	//get Id for modification
	@RequestMapping("getidformodify")
	public String getIdForModify(int id, Model model) {
		trainee = serObj.getTrainee(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		model.addAttribute("cityList", cityList);
		model.addAttribute("domain", domainList);
		return "modifyTrainee";
	}

	//validate Id
	@RequestMapping("checkModify")
	public String validateModify(@ModelAttribute("trainee") Trainee trainee, BindingResult result, Model model) {
		if (result.hasErrors()) {
			model.addAttribute("errMsg", "Provide valid details to modify");
			model.addAttribute("cityList", cityList);
			model.addAttribute("domain", domainList);
			return "modifyTrainee";
		} else {
			serObj.addTrainee(trainee);
			model.addAttribute("operation", "Trainee modified successfully!");
			return "traineeMenu";
		}
	}

	//modify the fetched details
	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model) {
		model.addAttribute("newTrainee", new Trainee());
		cityList = new ArrayList<String>();

		cityList.add("Chennai");
		cityList.add("Bangalore");
		cityList.add("Pune");
		cityList.add("Mumbai");

		domainList = new ArrayList<String>();

		domainList.add("Java");
		domainList.add("SAP");
		model.addAttribute("cityList", cityList);
		model.addAttribute("domainList", domainList);
		return "modifyTrainee";

	}

	//choice 4: Retrieve
	//retrieve one record 
 	@RequestMapping("getTrainee")
	public String getTrainee(int id, Model model) {
		Trainee trainee = serObj.getTrainee(id);
		System.out.println(trainee);
		model.addAttribute("trainee", trainee);
		return "retrieveOne";

	}

 	//navigate to retrieve page
	@RequestMapping("/retrieveOne")
	public String retrieveOne(Model model) {
		model.addAttribute("trainee", null);
		return "retrieveOne";
	}

	//retrieve all records
	@RequestMapping("/retrieveAll")
	public String retrieveAll(Model model) {
		Iterable<Trainee> itr = serObj.getAllTrainee();
		List<Trainee> list = new ArrayList<>();
		itr.forEach(list::add);
		for (Trainee trainee : list) {
			System.out.println(trainee);
		}
		model.addAttribute("traineeList", list);
		return "retrieveAll";
	}

}
