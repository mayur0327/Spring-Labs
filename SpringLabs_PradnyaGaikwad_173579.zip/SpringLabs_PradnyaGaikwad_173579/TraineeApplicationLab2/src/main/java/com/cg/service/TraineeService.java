package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {
	
	Trainee addTrainee(Trainee trainee);
	void deleteTrainee(Trainee trainee);
	Trainee modifyTrainee(int traineeId,Trainee t);
	Trainee getTrainee(int id);
	Iterable<Trainee> getAllTrainee();
	


}
