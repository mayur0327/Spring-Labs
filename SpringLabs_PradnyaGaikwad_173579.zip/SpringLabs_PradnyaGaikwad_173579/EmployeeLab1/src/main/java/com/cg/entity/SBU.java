package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

public class SBU {

	private int sbuId;
	private String sbuName;
	private String sbuHead;

	Employee empBean;

	public Employee getEmpBean() {
		return empBean;
	}

	public void setEmpBean(Employee empBean) {
		this.empBean = empBean;
	}

	// list of employees
	List<Employee> empList = new ArrayList<Employee>();

	public int getSbuId() {
		return sbuId;
	}

	public void setSbuId(int sbuId) {
		this.sbuId = sbuId;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	public List<Employee> getEmpList(Employee emp) {
		empList.add(emp);
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	@Override
	public String toString() {
		return "sbuId=" + sbuId + ",\n sbuName=" + sbuName + ",\n sbuHead=" + sbuHead;
	}
}
