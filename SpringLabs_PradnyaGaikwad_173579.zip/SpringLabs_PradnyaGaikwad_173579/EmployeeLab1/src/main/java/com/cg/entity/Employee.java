package com.cg.entity;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	private int employeeId;
	private String employeeName;
	private double employeeSalary;
	private String employeeBu;
	private int employeeAge;
	SBU sbuDetails;
	

	//list of employees
	List<Employee> empList;
	
	public List<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSalary() {
		return employeeSalary;
	}
	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	public String getEmployeeBu() {
		return employeeBu;
	}
	public void setEmployeeBu(String employeeBu) {
		this.employeeBu = employeeBu;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	
	
	public SBU getSbuDetails() {
		return sbuDetails;
	}
	public void setSbuDetails(SBU sbuDetails) {
		this.sbuDetails = sbuDetails;
	}
	@Override
	public String toString() {
		return " \n EmployeeId=" + employeeId + ",\n EmployeeName=" + employeeName + ",\n employeeSalary="
				+ employeeSalary + ",\n employeeBu=" + employeeBu + ",\n employeeAge=" + employeeAge;
	}
	
	
	
}
