package com.cg.client;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;
import com.cg.entity.SBU;

public class Client {

	public static void main(String[] args) {
		Scanner sc1 = new Scanner(System.in);
		int empId = 0;

		ApplicationContext ctx1 = new ClassPathXmlApplicationContext("Emp1.xml");
		ApplicationContext ctx2 = new ClassPathXmlApplicationContext("sbu1.xml");
		ApplicationContext ctx3 = new ClassPathXmlApplicationContext("Emp2.xml");

		// 1.1.Write an Employee bean. Inject values into bean using DI and display all
		// values.

		Employee employee = (Employee) ctx1.getBean("employee");
		System.out.println("Employee Details" + "\n" + "--------------");
		System.out.println(employee);

		// 1.2.provide a method to retrieve SBU details (getSBUDetails()) for the
		// employee
		
		SBU sbu = (SBU) ctx2.getBean("sbu");
		employee.setSbuDetails(sbu);
		System.out.println("\n Sbu Details" + "\n" + "--------------");
		System.out.println(employee.getSbuDetails());

		
		/*
		 * 1.3.In SBU bean, Create a new property called empList which will contain a
		 * list of all employees in the PES BU. Display the SBU details, followed by a
		 * list of all employees in that BU. To inject employee objects into the SBU
		 * bean,use �List� collection. Allocate two employees to PES
		 */
		Employee employee2 = (Employee) ctx3.getBean("employee1");
		Employee employee3 = (Employee) ctx3.getBean("employee2");

		sbu.getEmpList(employee2);
		System.out.println("--------\n" + sbu.getEmpList(employee3));

		// 1.4 Find employee by Id
		
		System.out.println("Enter employee id:");
		empId = sc1.nextInt();
		Employee emp = (Employee) ctx3.getBean("employeeList");
		for (Employee empObj : emp.getEmpList()) {
			if (empId == empObj.getEmployeeId()) {
				System.out.println(empObj);
			}
		}

	}

}
