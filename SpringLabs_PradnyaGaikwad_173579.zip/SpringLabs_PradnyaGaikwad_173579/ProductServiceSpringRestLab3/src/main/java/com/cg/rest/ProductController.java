package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@RestController
public class ProductController {

	@Autowired
	private ProductRepo repo;

	@GetMapping("/post")
	public ModelAndView showPostView() {
		return new ModelAndView("post", "product", new Product());
	}

	// add products
	@PostMapping(path = "/addProduct")
	public Product addProduct(@ModelAttribute("product") Product product, Model model) {
		product = repo.saveProduct(product);
		model.addAttribute("result", "Product added successfully!");
		return product;
	}

	// show all products
	@GetMapping(path = "/products", produces = "application/json")
	public List<Product> showAllProducts() {
		return repo.getAll();
	}

	//exception handling
	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })
	public ModelAndView showError() {
		return new ModelAndView("error");
	}
}
