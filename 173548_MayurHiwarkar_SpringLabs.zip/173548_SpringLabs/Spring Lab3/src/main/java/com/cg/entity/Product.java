package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product_info")
public class Product {

	@Id
	@Column(length = 20, name = "product_id")
	private int productId;

	@Column(length = 20, name = "product_name")
	private String productName;

	@Column(length = 20, name = "product_price")
	private double productPrice;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	@Override
	public String toString() {
		return "Product Info  : \nProduct Id : " + productId + "\nProduct Name : " + productName + "Product Price="
				+ productPrice;
	}

}