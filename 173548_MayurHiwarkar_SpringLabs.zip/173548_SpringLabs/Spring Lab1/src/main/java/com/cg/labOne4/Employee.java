package com.cg.labOne4;

import java.util.List;

public class Employee {
	public Employee() {

	}

	private int employeeId;

	private String name;

	private double salary;

	private List<Employee> empList;

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(List<Employee> empList) {

		this.empList = empList;
	}

	@Override
	public String toString() {

		return "Employee Info : \nEmployee ID : " + employeeId + "\nEmployee Name : " + name + "\nEmployee Salary : "
				+ salary;
	}

}
