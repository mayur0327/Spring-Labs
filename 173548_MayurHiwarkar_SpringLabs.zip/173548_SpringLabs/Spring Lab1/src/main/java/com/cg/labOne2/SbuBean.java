package com.cg.labOne2;

public class SbuBean {

	private String sbuCode;

	private String sbuName;

	private String sbuhead;

	public SbuBean() {

	}

	public SbuBean(String sbuCode, String sbuName, String sbuhead) {
		super();
		this.sbuCode = sbuCode;
		this.sbuName = sbuName;
		this.sbuhead = sbuhead;
	}

	public String getSbuCode() {
		return sbuCode;
	}

	public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}

	public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuhead() {
		return sbuhead;
	}

	public void setSbuhead(String sbuhead) {
		this.sbuhead = sbuhead;
	}

	@Override
	public String toString() {

		return "Sbu : [SbuName : " + sbuName + " , sbuHead : " + sbuhead + " , sbuCode : " + sbuCode + " ] ";
	}

}
