package com.cg.labOne2;

public class Employee {
	public Employee() {

	}

	private int employeeId;

	private String name;

	private double salary;

	private String buUnit;

	private int age;

	SbuBean sbu;

	public SbuBean getSbu() {
		return sbu;
	}

	public void setSbu(SbuBean sbu) {
		this.sbu = sbu;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getBuUnit() {
		return buUnit;
	}

	public void setBuUnit(String buUnit) {
		this.buUnit = buUnit;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Employee(int id, String name, double salary, String buUnit, int age) {

		this.employeeId = id;
		this.name = name;
		this.salary = salary;
		this.buUnit = buUnit;
		this.age = age;
	}

	@Override
	public String toString() {

		return "Employee ID : " + employeeId + "\nEmployee Name : " + name + "\nEmployee Salary : " + salary
				+ "\nEmployee BU : " + buUnit + "\nEmployee Age : " + age + "\n Sbu : " + sbu;
	}

}
