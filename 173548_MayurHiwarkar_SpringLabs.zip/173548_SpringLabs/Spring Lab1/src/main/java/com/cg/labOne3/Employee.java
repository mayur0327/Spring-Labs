package com.cg.labOne3;

public class Employee {
	public Employee() {

	}

	private int employeeId;

	private String name;

	private double salary;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public Employee(int id, String name, double salary) {

		this.employeeId = id;
		this.name = name;
		this.salary = salary;

	}

	@Override
	public String toString() {

		return " [ Employee ID : " + employeeId + "\nEmployee Name : " + name + "\nEmployee Salary : " + salary + " ] \n";
	}

}
