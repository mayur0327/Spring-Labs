package com.cg.labOne1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.labOne1.Employee;

public class Client {

	public static void main(String[] args) {

		ApplicationContext actx = new ClassPathXmlApplicationContext("Employee1.xml");

		Employee eobj = (Employee) actx.getBean("emp");

		System.out.println(eobj);

	}

}
