package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeService {

	void registerTrainee(Trainee tr);

	Trainee get(int id);

	void delete(Trainee tr);

	Iterable<Trainee> getAll();
}
