package com.cg.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.Trainee;

public interface TrainingRepo extends JpaRepository<Trainee, Integer> {

}
