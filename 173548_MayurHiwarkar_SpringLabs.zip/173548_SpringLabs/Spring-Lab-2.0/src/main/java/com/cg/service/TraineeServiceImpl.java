package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Trainee;
import com.cg.repo.TrainingRepo;

@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	private TrainingRepo repo;

	@Override
	public void registerTrainee(Trainee tr) {
		repo.save(tr);

	}

	@Override
	public Trainee get(int id) {
		return repo.findOne(id);
	}

	@Override
	public void delete(Trainee tr) {
		repo.delete(tr);
	}

	@Override
	public Iterable<Trainee> getAll() {

		return repo.findAll();
	}

}
