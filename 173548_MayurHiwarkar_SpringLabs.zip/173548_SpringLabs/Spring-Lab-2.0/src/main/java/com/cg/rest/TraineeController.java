package com.cg.rest;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	private TraineeService sobj;

	ArrayList<String> locationList;
	ArrayList<String> domainList;
	Trainee tobj;

	@RequestMapping("/")
	public String login(Model m) {
		m.addAttribute("login", new Login());
		return "login";
	}

	@RequestMapping(value = "/checkLogin")
	public String checkLogin(@ModelAttribute("login") @Valid Login log, BindingResult result, Model m) {

		if (result.hasErrors()) {

			return "login";
		} else {
			if (log.getUserName().equals("admin@abc.com") && log.getPassWord().equals("12345"))
				return "menu";
			else {
				m.addAttribute("logindetails", "Wrong Credentials");
				return "login";
			}
		}

	}

	@RequestMapping("/register")
	public String regiserTrainee(Model m) {
		m.addAttribute("tr", new Trainee());

		locationList = new ArrayList<String>();

		locationList.add("Nagpur");
		locationList.add("Pune");
		locationList.add("Bnagalore");

		domainList = new ArrayList<String>();

		domainList.add("Java FS");
		domainList.add("Dot NEt");
		domainList.add("Power BI");

		m.addAttribute("locationList", locationList);
		m.addAttribute("domainList", domainList);
		return "register";
	}

	@RequestMapping("/regTrainee")
	public String enterTrainee(@ModelAttribute("tr") @Valid Trainee tr, BindingResult result, Model m) {
		if (result.hasErrors()) {
			m.addAttribute("error", "Add Valid Data");
			m.addAttribute("locationList", locationList);
			m.addAttribute("domainList", domainList);
			return "register";
		} else {
			sobj.registerTrainee(tr);
			m.addAttribute("success", "Data Added Successfuuly");
			return "menu";
		}
	}

	@RequestMapping("/del")
	public String delete(Model m) {
		m.addAttribute("tr", null);
		return "delete";
	}

	@RequestMapping("getId")
	public String getIdToDelete(int id, Model m) {
		tobj = sobj.get(id);
		System.out.println(tobj);
		m.addAttribute("tr", tobj);
		return "delete";
	}

	@RequestMapping("delete")
	public String deleteTrainee(Model m) {

		System.out.println(tobj);
		if (tobj != null) {
			sobj.delete(tobj);
			tobj = null;
			m.addAttribute("successfull", "Delete Successfull");
			return "menu";
		} else {
			m.addAttribute("error", "Delete Not Successfull");
			return "delete";
		}
	}

	@RequestMapping("/mod")
	public String modify(Model m) {

		locationList = new ArrayList<String>();

		locationList.add("Nagpur");
		locationList.add("Pune");
		locationList.add("Bnagalore");

		domainList = new ArrayList<String>();

		domainList.add("Java FS");
		domainList.add("Dot NEt");
		domainList.add("Power BI");

		m.addAttribute("locationList", locationList);
		m.addAttribute("domainList", domainList);
		m.addAttribute("tr", new Trainee());
		return "update";
	}

	@RequestMapping("getModId")
	public String getIdToModify(int id, Model m) {
		tobj = sobj.get(id);
		System.out.println(tobj);

		m.addAttribute("tr", tobj);
		m.addAttribute("locationList", locationList);
		m.addAttribute("domainList", domainList);
		return "update";

	}

	@RequestMapping("modify")
	public String modifyTrainee(@ModelAttribute("tr") Trainee tr, BindingResult result, Model m) {
		if (result.hasErrors()) {
			m.addAttribute("error", "Data not correct");
			m.addAttribute("locationList", locationList);
			m.addAttribute("domainList", domainList);
			return "update";
		} else {
			sobj.registerTrainee(tr);
			m.addAttribute("success", "Data Updated Successfully");
			return "menu";
		}
	}

	@RequestMapping("/get")
	public String getInfo(Model m) {
		m.addAttribute("tr", null);
		return "retrieve";
	}

	@RequestMapping("getTrainee")
	public String getTrainee(int id, Model m) {
		Trainee trobj = sobj.get(id);
		System.out.println(trobj);
		m.addAttribute("tr", trobj);
		return "retrieve";
	}

	@RequestMapping("/getAll")
	public String retrieveAll(Model model) {
		Iterable<Trainee> iterable = sobj.getAll();
		List<Trainee> list = new ArrayList<>();
		iterable.forEach(list::add);
		for (Trainee trobj : list) {
			System.out.println(trobj);
		}
		model.addAttribute("list", list);
		return "getAll";
	}

}
