package com.cg.entity;

import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

public class Login {

	@NotEmpty(message = "User Name is Mandatory")
	@Size(min = 4, max = 10)
	private String userName;

	@NotEmpty(message = "Password is Mandatory")
	@Size(min = 4, max = 10)
	private String passWord;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassWord() {
		return passWord;
	}

	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

}
